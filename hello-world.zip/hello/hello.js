"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.helloWorld = void 0;
const helloWorld = () => {
    console.log("ffffffwewrwewr");
};
exports.helloWorld = helloWorld;
